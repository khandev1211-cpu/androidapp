# Video Downloader Android App

A Kivy-based Android application for downloading videos from YouTube and TikTok.

## Features

- 🎥 Download YouTube videos and playlists
- 🎵 Download TikTok videos  
- 📱 Mobile-optimized dark theme UI
- 🎯 Multiple quality options (1080p, 720p, 480p, 360p, Audio-only)
- 📋 Download history tracking
- 📋 Clipboard integration (paste/copy URLs)
- 📊 Real-time download progress

## Requirements

### For Development
- Python 3.13
- Kivy 2.3.1
- yt-dlp 2024.1.0
- Buildozer (for Android packaging)

### For Android
- Android API 21+ (Android 5.0+)
- Storage permissions
- Internet connection

## Setup Instructions

### Method 1: Pydroid3 (Recommended for Testing)

1. Install Pydroid3 from Google Play Store
2. Open Pydroid3 and go to "PIP" section
3. Install required packages:
   ```
   pip install kivy==2.3.1 yt-dlp==2024.1.0 pillow==10.2.0 requests==2.31.0
   ```
4. Copy `app.py` to your device
5. Run the app through Pydroid3

### Method 2: Build APK with Buildozer

1. Install Buildozer:
   ```bash
   pip install buildozer
   ```

2. Install required dependencies:
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install -y python3-pip build-essential git python3 python3-dev
   sudo apt install -y libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev
   sudo apt install -y libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev
   sudo apt install -y default-jdk autoconf libtool pkg-config
   sudo apt install -y libssl-dev
   
   # Download Android SDK and NDK
   # Set environment variables:
   export ANDROID_HOME=/path/to/android-sdk
   export ANDROID_NDK_HOME=/path/to/android-ndk
   ```

3. Build the APK:
   ```bash
   buildozer android debug
   ```

4. Install the APK:
   ```bash
   adb install bin/videodownloader-1.0-debug.apk
   ```

### Method 3: Using Python-for-Android

1. Install python-for-android:
   ```bash
   pip install python-for-android
   ```

2. Create the APK:
   ```bash
   p4a apk --private . --package=org.khanxs.videodownloader --name "Video Downloader" --version=1.0 --bootstrap=sdl2 --requirements=python3,kivy==2.3.1,yt-dlp==2024.1.0,pillow==10.2.0,requests==2.31.0
   ```

## File Structure

```
APP-android/
├── app.py              # Main application code
├── requirements.txt    # Python dependencies
├── buildozer.spec      # Build configuration
├── README.md          # This file
└── bin/               # Generated APK files (after build)
```

## Usage

1. **Enter URL**: Paste or type a YouTube/TikTok URL
2. **Select Quality**: Choose from available quality options
3. **Download**: Tap the download button
4. **Track Progress**: Monitor download in real-time
5. **View History**: Access previous downloads

## Storage

- **Downloads**: `/storage/emulated/0/Download/VideoDownloads/`
- **History**: `~/download_history.json`
- **Archive**: `~/downloaded_videos.txt`

## Permissions Required

- `WRITE_EXTERNAL_STORAGE` - Save downloaded videos
- `READ_EXTERNAL_STORAGE` - Access existing files
- `INTERNET` - Download video content

## Troubleshooting

### Common Issues

1. **Build fails with NDK errors**
   - Ensure correct NDK version (25b)
   - Check ANDROID_NDK_HOME environment variable

2. **App crashes on download**
   - Check internet connection
   - Verify URL is valid
   - Ensure storage permissions granted

3. **yt-dlp import error**
   - Update yt-dlp: `pip install --upgrade yt-dlp`
   - Check Python version compatibility

### Debug Mode

Enable debug logging in `buildozer.spec`:
```
android.logcat_filters = *:S python:D
```

## Development

### Running on Desktop

```bash
python app.py
```

### Testing Changes

1. Modify `app.py`
2. Test with Pydroid3 first
3. Build APK only after desktop testing

### Customization

- **Theme**: Modify color constants at top of `app.py`
- **Features**: Add new platforms in download logic
- **UI**: Adjust widget layouts in `_build_ui()` methods

## License

This project is for educational purposes. Please respect terms of service of video platforms.

## Support

For issues and questions:
1. Check this README
2. Review app.py comments
3. Test with Pydroid3 before building APK
