"""
Multi-Platform Video Downloader - Kivy UI
Optimized for Pydroid3 on Android (Python 3.13 + Kivy 2.3.1)

Install dependencies in Pydroid3 pip terminal:
    pip install kivy yt-dlp
"""

import os
import json
import threading
import zipfile
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

# ── Kivy config MUST happen before any other kivy import ──────────────────────
from kivy.config import Config
Config.set("graphics", "resizable", "1")
Config.set("input", "mouse", "mouse,disable_multitouch")
# Tell Kivy NOT to resize the window when the soft keyboard appears.
# "pan" mode shifts the view up so the focused input stays visible —
# this prevents the window collapsing and the TextInput losing focus
# on Pydroid3 / Android.
Config.set("kivy", "keyboard_mode", "system")
# ─────────────────────────────────────────────────────────────────────────────

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.metrics import dp, sp
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line
from kivy.uix.widget import Widget


# ─── THEME ────────────────────────────────────────────────────────────────────

BG      = "#0D0F14"
SURFACE = "#161920"
CARD    = "#1E2330"
ACCENT  = "#FF4D6D"
ACCENT2 = "#00C9A7"
TEXT    = "#F0F4FF"
MUTED   = "#7B849A"
BORDER  = "#2A2F3E"

def c(code):
    """Shorthand: hex string → RGBA tuple."""
    return get_color_from_hex(code)


# ─── HISTORY HELPERS ──────────────────────────────────────────────────────────

HISTORY_FILE = os.path.join(
    os.path.expanduser("~"), "download_history.json"
)
ARCHIVE_FILE = os.path.join(
    os.path.expanduser("~"), "downloaded_videos.txt"
)
DOWNLOADS_DIR = os.path.join(
    "/storage/emulated/0/Download", "VideoDownloads"
)


def load_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_history(history):
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


# ─── REUSABLE STYLED WIDGETS ─────────────────────────────────────────────────

class BgRect:
    """Mixin: draws a solid rounded rectangle behind a widget."""
    def _init_bg(self, color=CARD, radius=14):
        self._bg_color_hex = color
        self._bg_radius = radius
        self.bind(pos=self._redraw_bg, size=self._redraw_bg)

    def _redraw_bg(self, *_):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*c(self._bg_color_hex))
            RoundedRectangle(
                pos=self.pos, size=self.size,
                radius=[dp(self._bg_radius)]
            )
            Color(*c(BORDER))
            Line(
                rounded_rectangle=(
                    self.x, self.y, self.width, self.height,
                    dp(self._bg_radius)
                ),
                width=1,
            )


class DarkLabel(Label):
    def __init__(self, **kw):
        kw.setdefault("color", c(TEXT))
        kw.setdefault("font_size", sp(15))
        kw.setdefault("halign", "left")
        kw.setdefault("valign", "middle")
        super().__init__(**kw)
        self.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))


class MutedLabel(DarkLabel):
    def __init__(self, **kw):
        kw.setdefault("color", c(MUTED))
        kw.setdefault("font_size", sp(13))
        super().__init__(**kw)


class Divider(Widget):
    def __init__(self, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(1))
        super().__init__(**kw)
        self.bind(pos=self._draw, size=self._draw)

    def _draw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*c(BORDER))
            Rectangle(pos=self.pos, size=self.size)


class CardBox(BgRect, BoxLayout):
    def __init__(self, **kw):
        super().__init__(**kw)
        self._init_bg(CARD, 14)


class AccentButton(BgRect, Button):
    """Red accent button."""
    def __init__(self, color_hex=ACCENT, **kw):
        kw.setdefault("font_size", sp(15))
        kw.setdefault("bold", True)
        kw.setdefault("background_color", (0, 0, 0, 0))
        kw.setdefault("color", c(TEXT))
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(50))
        self._color_hex = color_hex
        super().__init__(**kw)
        self._bg_color_hex = color_hex
        self._bg_radius = 12
        self.bind(pos=self._redraw_bg, size=self._redraw_bg)

    def on_press(self):
        orig = self._bg_color_hex
        self._bg_color_hex = ACCENT2
        self._redraw_bg()
        Clock.schedule_once(lambda dt: self._restore(orig), 0.15)

    def _restore(self, orig):
        self._bg_color_hex = orig
        self._redraw_bg()


class SecondaryButton(AccentButton):
    def __init__(self, **kw):
        super().__init__(color_hex=CARD, **kw)

    def on_press(self):
        orig = self._bg_color_hex
        self._bg_color_hex = BORDER
        self._redraw_bg()
        Clock.schedule_once(lambda dt: self._restore(orig), 0.15)


class DarkInput(BgRect, TextInput):
    def __init__(self, **kw):
        kw.setdefault("foreground_color", (1, 1, 1, 1))  # pure white text
        # Set background to fully transparent so our canvas BgRect shows through.
        # background_color alone is not enough on Android — must also clear the
        # normal/active image paths so Kivy doesn't draw its own white box.
        kw.setdefault("background_color", (0, 0, 0, 0))
        kw.setdefault("background_normal", "")
        kw.setdefault("background_active", "")
        kw.setdefault("cursor_color", c(ACCENT))
        kw.setdefault("selection_color", (*c(ACCENT)[:3], 0.35))
        kw.setdefault("font_size", sp(14))
        kw.setdefault("padding", [dp(14), dp(14), dp(14), dp(14)])
        kw.setdefault("multiline", False)
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(52))
        super().__init__(**kw)
        self._init_bg(CARD, 12)


# ─── QUALITY POPUP ────────────────────────────────────────────────────────────

QUALITIES = [
    ("🏆  Best Quality",       "best[ext=mp4]",                     "BEST"),
    ("🎬  1080p HD",           "best[height<=1080][ext=mp4]",       "1080p"),
    ("📺  720p",               "best[height<=720][ext=mp4]",        "720p"),
    ("📱  480p",               "best[height<=480][ext=mp4]",        "480p"),
    ("🔋  360p  (Data Saver)", "best[height<=360][ext=mp4]",        "360p"),
    ("🎵  Audio Only  (m4a)",  "bestaudio[ext=m4a]/bestaudio/best", "AUDIO"),
]


def make_quality_popup(on_select):
    outer = BoxLayout(
        orientation="vertical", padding=dp(16), spacing=dp(10)
    )
    # Background
    with outer.canvas.before:
        Color(*c(SURFACE))
        _r = Rectangle()
    outer.bind(
        pos=lambda w, *_: setattr(_r, "pos", w.pos),
        size=lambda w, *_: setattr(_r, "size", w.size),
    )

    outer.add_widget(
        Label(
            text="[b]Select Quality[/b]",
            markup=True,
            font_size=sp(18),
            color=c(TEXT),
            size_hint_y=None,
            height=dp(36),
            halign="center",
        )
    )
    outer.add_widget(Divider())

    pop = Popup(
        title="",
        separator_height=0,
        content=outer,
        size_hint=(0.92, None),
        height=dp(440),
        background="",
        background_color=(0, 0, 0, 0),
    )

    for label, fmt, name in QUALITIES:
        btn = Button(
            text=label,
            font_size=sp(15),
            size_hint_y=None,
            height=dp(50),
            background_color=(0, 0, 0, 0),
            color=c(TEXT),
            halign="left",
            text_size=(None, None),
        )
        btn._fmt  = fmt
        btn._name = name

        # draw card bg
        with btn.canvas.before:
            _bc = Color(*c(CARD))
            _br = RoundedRectangle(radius=[dp(10)])
        btn.bind(
            pos=lambda w, *_: setattr(_br, "pos", w.pos),
            size=lambda w, *_: setattr(_br, "size", w.size),
        )
        # close-over the right _br per button
        def _make_bind(r):
            def _b(w, *_):
                r.pos  = w.pos
                r.size = w.size
            return _b
        btn.bind(pos=_make_bind(_br), size=_make_bind(_br))

        def _pick(b, *_):
            pop.dismiss()
            on_select(b._fmt, b._name)

        btn.bind(on_press=_pick)
        outer.add_widget(btn)

    return pop


# ─── PROGRESS POPUP ───────────────────────────────────────────────────────────

class ProgressPopup(Popup):
    def __init__(self, **kw):
        content = BoxLayout(
            orientation="vertical", padding=dp(20), spacing=dp(12)
        )
        with content.canvas.before:
            Color(*c(SURFACE))
            _r = Rectangle()
        content.bind(
            pos=lambda w, *_: setattr(_r, "pos", w.pos),
            size=lambda w, *_: setattr(_r, "size", w.size),
        )

        self._status = Label(
            text="Preparing…",
            font_size=sp(14),
            bold=True,
            color=c(TEXT),
            size_hint_y=None,
            height=dp(30),
            halign="center",
        )
        self._status.bind(
            width=lambda w, v: setattr(w, "text_size", (v, None))
        )
        self._bar = ProgressBar(max=100, value=0, size_hint_y=None, height=dp(12))
        self._detail = Label(
            text="",
            font_size=sp(12),
            color=c(MUTED),
            size_hint_y=None,
            height=dp(22),
            halign="center",
        )
        self._detail.bind(
            width=lambda w, v: setattr(w, "text_size", (v, None))
        )

        content.add_widget(self._status)
        content.add_widget(self._bar)
        content.add_widget(self._detail)

        kw.update(
            dict(
                title="",
                separator_height=0,
                content=content,
                size_hint=(0.88, None),
                height=dp(170),
                background="",
                background_color=(0, 0, 0, 0),
                auto_dismiss=False,
            )
        )
        super().__init__(**kw)

    def update(self, status, detail="", progress=None):
        """Thread-safe update."""
        def _do(dt):
            self._status.text = status
            self._detail.text = detail
            if progress is not None:
                self._bar.value = max(0.0, min(100.0, float(progress)))
        Clock.schedule_once(_do)


# ─── HOME SCREEN ──────────────────────────────────────────────────────────────

class HomeScreen(Screen):
    def __init__(self, **kw):
        super().__init__(**kw)
        with self.canvas.before:
            Color(*c(BG))
            self._bg = Rectangle()
        self.bind(pos=self._upd_bg, size=self._upd_bg)
        self._build_ui()

    def _upd_bg(self, *_):
        self._bg.pos  = self.pos
        self._bg.size = self.size

    # ── Build ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        scroll = ScrollView(do_scroll_x=False)
        root = BoxLayout(
            orientation="vertical",
            padding=dp(18),
            spacing=dp(14),
            size_hint_y=None,
        )
        root.bind(minimum_height=root.setter("height"))

        # Header
        root.add_widget(self._header())

        # URL card
        url_card = CardBox(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(168),
        )
        url_card.add_widget(
            DarkLabel(
                text="[b]Enter URL[/b]",
                markup=True,
                font_size=sp(14),
                size_hint_y=None,
                height=dp(22),
            )
        )
        self.url_input = DarkInput(
            hint_text="https://youtube.com/watch?v=...",
            hint_text_color=(1, 1, 1, 0.4),
        )
        url_card.add_widget(self.url_input)

        # Paste + Copy side by side
        btn_row = BoxLayout(
            orientation="horizontal",
            spacing=dp(10),
            size_hint_y=None,
            height=dp(42),
        )
        paste_btn = SecondaryButton(text="📋  Paste", height=dp(42))
        paste_btn.bind(on_press=self._paste)
        copy_btn = SecondaryButton(text="📄  Copy URL", height=dp(42))
        copy_btn.bind(on_press=self._copy)
        btn_row.add_widget(paste_btn)
        btn_row.add_widget(copy_btn)
        url_card.add_widget(btn_row)
        root.add_widget(url_card)

        # Download button
        dl_btn = AccentButton(text="⬇   DOWNLOAD")
        dl_btn.bind(on_press=self._start_download)
        root.add_widget(dl_btn)

        # Tips card
        root.add_widget(self._tips_card())

        # Navigation row
        nav = GridLayout(cols=3, spacing=dp(8), size_hint_y=None, height=dp(50))
        build_btn = SecondaryButton(text="🔨  Build APK")
        build_btn.bind(on_press=lambda *_: self._goto("build"))
        hist_btn = SecondaryButton(text="📜  History")
        hist_btn.bind(on_press=lambda *_: self._goto("history"))
        about_btn = SecondaryButton(text="ℹ️  About")
        about_btn.bind(on_press=self._show_about)
        nav.add_widget(build_btn)
        nav.add_widget(hist_btn)
        nav.add_widget(about_btn)
        root.add_widget(nav)

        root.add_widget(Widget(size_hint_y=None, height=dp(24)))

        scroll.add_widget(root)
        self.add_widget(scroll)

    def _header(self):
        box = BoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(88),
            spacing=dp(4),
        )
        box.add_widget(
            Label(
                text="[b]VIDEO[/b] [color=#FF4D6D]DOWNLOADER[/color]",
                markup=True,
                font_size=sp(26),
                color=c(TEXT),
                size_hint_y=None,
                height=dp(48),
                halign="center",
            )
        )
        box.add_widget(
            MutedLabel(
                text= "Powerd By Khan X S",
                font_size=sp(13),
                halign="center",
                size_hint_y=None,
                height=dp(26),
            )
        )
        return box

    def _tips_card(self):
        tips = [
            "• Supports YouTube videos & playlists",
            "• Supports TikTok videos"  ]
        card = CardBox(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(4),
            size_hint_y=None,
            height=dp(110),
        )
        card.add_widget(
            DarkLabel(
                text="[b]Quick Tips[/b]",
                markup=True,
                font_size=sp(14),
                size_hint_y=None,
                height=dp(26),
            )
        )
        for tip in tips:
            card.add_widget(
                MutedLabel(
                    text=tip,
                    font_size=sp(12.5),
                    size_hint_y=None,
                    height=dp(22),
                )
            )
        return card

    # ── Actions ──────────────────────────────────────────────────────────────

    def _goto(self, name):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = name

    def _paste(self, *_):
        try:
            from kivy.core.clipboard import Clipboard
            txt = Clipboard.paste()
            if txt:
                self.url_input.text = txt.strip()
            else:
                self._toast("Clipboard is empty")
        except Exception as e:
            self._toast(f"Clipboard error: {e}")


    def _copy(self, *_):
        try:
            from kivy.core.clipboard import Clipboard
            url = self.url_input.text.strip()
            if url:
                Clipboard.copy(url)
                self._toast("✅ URL copied to clipboard!")
            else:
                self._toast("⚠️ Nothing to copy — input is empty")
        except Exception as e:
            self._toast(f"Clipboard error: {e}")

    def _start_download(self, *_):
        url = self.url_input.text.strip()
        if not url:
            self._toast("⚠️ Please enter a URL first")
            return
        pop = make_quality_popup(
            on_select=lambda fmt, name: self._run_download(url, fmt, name)
        )
        pop.open()

    def _run_download(self, url, fmt, quality_name):
        prog = ProgressPopup()
        prog.open()

        # yt-dlp needs a logger object with .debug/.warning/.error methods.
        # Using quiet=True alone can cause "str has no attribute write" on
        # some yt-dlp builds because it sets the internal stream to a string.
        # A proper no-op logger avoids this entirely.
        class _NullLogger:
            def debug(self, msg):    pass
            def warning(self, msg):  pass
            def error(self, msg):    pass

        def worker():
            try:
                import yt_dlp
            except ImportError:
                prog.update("❌ yt-dlp not installed",
                            "Run:  pip install yt-dlp")
                Clock.schedule_once(lambda dt: prog.dismiss(), 3)
                return

            history = load_history()
            platform = "tiktok" if "tiktok.com" in url.lower() else "youtube"

            prog.update("🔍 Analysing URL…", progress=5)

            base_opts = {
                "logger": _NullLogger(),   # replaces quiet=True safely
                "no_warnings": True,
                "noprogress": True,        # don't write progress to stdout
                "noplaylist": platform != "youtube",
                "nocheckcertificate": True,
                "extractor_retries": 3,
                "socket_timeout": 30,
                "user_agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36"
                ),
            }
            cookies = os.path.join(
                "/storage/emulated/0/Download", "cookies.txt"
            )
            if os.path.exists(cookies):
                base_opts["cookiefile"] = cookies

            # Extract info
            try:
                with yt_dlp.YoutubeDL(base_opts) as ydl:
                    info = ydl.extract_info(url, download=False)
            except Exception as e:
                prog.update("❌ Could not analyse URL", str(e)[:70])
                Clock.schedule_once(lambda dt: prog.dismiss(), 3)
                return

            title = info.get("title", "Unknown")
            is_playlist = (
                "entries" in info
                and info["entries"]
                and platform == "youtube"
            )

            if is_playlist:
                prog.update(
                    f"📋 Playlist · {len(info['entries'])} videos",
                    title[:50],
                    progress=10,
                )
            else:
                prog.update(
                    f"⬇️ Downloading {quality_name}",
                    title[:50],
                    progress=10,
                )

            # Progress hook — yt-dlp calls this from the download thread
            def hook(d):
                if d["status"] == "downloading":
                    pct_str = d.get("_percent_str", "0%").strip().rstrip("%")
                    try:
                        pct = float(pct_str)
                    except ValueError:
                        pct = 0.0
                    prog.update("⬇️ Downloading…", f"{pct:.1f}%", progress=pct)
                elif d["status"] == "finished":
                    prog.update("✅ Download complete!", "Processing file…", progress=95)
                elif d["status"] == "error":
                    prog.update("❌ Download failed", d.get("error", "Unknown error"), progress=0)

            # Download options
            download_opts = base_opts.copy()
            download_opts.update({
                "format": fmt,
                "outtmpl": os.path.join(DOWNLOADS_DIR, f"%(title)s.%(ext)s"),
                "progress_hooks": [hook],
                "postprocessors": [
                    {
                        "key": "FFmpegVideoConvertor",
                        "preferedformat": "mp4",
                    }
                ] if quality_name != "AUDIO" else [],
            })

            # Ensure download directory exists
            os.makedirs(DOWNLOADS_DIR, exist_ok=True)

            # Start download
            try:
                with yt_dlp.YoutubeDL(download_opts) as ydl:
                    ydl.download([url])
                
                prog.update("🎉 Success!", f"Saved to {DOWNLOADS_DIR}", progress=100)
                Clock.schedule_once(lambda dt: prog.dismiss(), 3)
                
                # Save to history
                history = load_history()
                history[datetime.now().isoformat()] = {
                    "url": url,
                    "title": title,
                    "quality": quality_name,
                    "platform": platform,
                }
                save_history(history)
                
            except Exception as e:
                prog.update("❌ Download failed", str(e)[:70], progress=0)
                Clock.schedule_once(lambda dt: prog.dismiss(), 3)

        threading.Thread(target=worker, daemon=True).start()

    def _toast(self, message):
        """Simple toast notification."""
        popup = Popup(
            title="",
            content=Label(
                text=message,
                color=c(TEXT),
                font_size=sp(14),
                padding=dp(20),
            ),
            size_hint=(0.8, None),
            height=dp(80),
            background_color=(0, 0, 0, 0.8),
            separator_height=0,
        )
        popup.open()
        Clock.schedule_once(lambda dt: popup.dismiss(), 2.5)

    def _show_about(self, *_):
        """Show about popup."""
        content = BoxLayout(
            orientation="vertical", 
            padding=dp(20), 
            spacing=dp(10)
        )
        content.add_widget(
            DarkLabel(
                text="[b]Video Downloader v1.0[/b]",
                markup=True,
                font_size=sp(18),
                halign="center",
                size_hint_y=None,
                height=dp(30)
            )
        )
        content.add_widget(
            MutedLabel(
                text="Built with Kivy + yt-dlp\n"
                     "Download videos from YouTube & TikTok\n"
                     "Multiple quality options available",
                halign="center",
                size_hint_y=None,
                height=dp(80)
            )
        )
        content.add_widget(
            MutedLabel(
                text="Created by Khan X S",
                halign="center",
                size_hint_y=None,
                height=dp(30)
            )
        )
        
        popup = Popup(
            title="About",
            content=content,
            size_hint=(0.85, 0.6),
            background_color=c(SURFACE)
        )
        popup.open()


# ─── APK BUILDER SCREEN ───────────────────────────────────────────────────────────

class BuildScreen(Screen):
    def __init__(self, **kw):
        super().__init__(**kw)
        with self.canvas.before:
            Color(*c(BG))
            self._bg = Rectangle()
        self.bind(pos=self._upd_bg, size=self._upd_bg)
        self._build_ui()
        self._build_process = None

    def _upd_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size

    def _build_ui(self):
        scroll = ScrollView(do_scroll_x=False)
        root = BoxLayout(
            orientation="vertical",
            padding=dp(18),
            spacing=dp(14),
            size_hint_y=None,
        )
        root.bind(minimum_height=root.setter("height"))

        # Header
        root.add_widget(self._header())

        # Build info card
        info_card = CardBox(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(120),
        )
        info_card.add_widget(
            DarkLabel(
                text="[b]APK Builder[/b]",
                markup=True,
                font_size=sp(16),
                size_hint_y=None,
                height=dp(26),
            )
        )
        info_card.add_widget(
            MutedLabel(
                text="Build Android APK directly from this app\n"
                     "Includes all features and dependencies\n"
                     "Ready for distribution",
                font_size=sp(12),
                size_hint_y=None,
                height=dp(70),
            )
        )
        root.add_widget(info_card)

        # Build button
        self.build_btn = AccentButton(text="🔨 BUILD APK")
        self.build_btn.bind(on_press=self._start_build)
        root.add_widget(self.build_btn)

        # Progress area
        self.progress_card = CardBox(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(150),
        )
        self.progress_label = DarkLabel(
            text="Ready to build...",
            font_size=sp(14),
            size_hint_y=None,
            height=dp(26),
        )
        self.progress_bar = ProgressBar(
            max=100, value=0, 
            size_hint_y=None, 
            height=dp(12)
        )
        self.progress_detail = MutedLabel(
            text="",
            font_size=sp(12),
            size_hint_y=None,
            height=dp(22),
        )
        
        self.progress_card.add_widget(self.progress_label)
        self.progress_card.add_widget(self.progress_bar)
        self.progress_card.add_widget(self.progress_detail)
        root.add_widget(self.progress_card)

        # Status area
        self.status_card = CardBox(
            orientation="vertical",
            padding=dp(16),
            spacing=dp(8),
            size_hint_y=None,
            height=dp(100),
        )
        self.status_label = MutedLabel(
            text="Build status will appear here",
            font_size=sp(12),
            size_hint_y=None,
            height=dp(80),
        )
        self.status_card.add_widget(self.status_label)
        root.add_widget(self.status_card)

        # Navigation
        nav = BoxLayout(
            orientation="horizontal",
            spacing=dp(10),
            size_hint_y=None,
            height=dp(50),
        )
        back_btn = SecondaryButton(text="🔙  Back")
        back_btn.bind(on_press=lambda *_: self._goto("home"))
        nav.add_widget(back_btn)
        root.add_widget(nav)

        root.add_widget(Widget(size_hint_y=None, height=dp(24)))

        scroll.add_widget(root)
        self.add_widget(scroll)

    def _header(self):
        box = BoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(88),
            spacing=dp(4),
        )
        box.add_widget(
            Label(
                text="[b]APK[/b] [color=#FF4D6D]BUILDER[/color]",
                markup=True,
                font_size=sp(26),
                color=c(TEXT),
                size_hint_y=None,
                height=dp(48),
                halign="center",
            )
        )
        box.add_widget(
            MutedLabel(
                text="Build Android Application",
                font_size=sp(13),
                halign="center",
                size_hint_y=None,
                height=dp(26),
            )
        )
        return box

    def _goto(self, name):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = name

    def _update_progress(self, status, detail="", progress=None):
        """Update build progress."""
        def _do(dt):
            self.progress_label.text = status
            self.progress_detail.text = detail
            if progress is not None:
                self.progress_bar.value = max(0.0, min(100.0, float(progress)))
        Clock.schedule_once(_do)

    def _update_status(self, message):
        """Update status message."""
        def _do(dt):
            self.status_label.text = message
        Clock.schedule_once(_do)

    def _start_build(self, *_):
        """Start the APK build process."""
        if self._build_process and self._build_process.is_alive():
            self._update_status("⚠️ Build already in progress...")
            return

        self.build_btn.disabled = True
        self._update_progress("🔨 Starting build...", "Initializing build environment", 5)
        
        # Start build in background thread
        self._build_process = threading.Thread(target=self._build_apk, daemon=True)
        self._build_process.start()

    def _build_apk(self):
        """Build APK using available methods."""
        try:
            self._update_progress("📦 Preparing build...", "Checking dependencies", 10)
            
            # Method 1: Try to use buildozer if available
            if self._try_buildozer():
                return
            
            # Method 2: Create package zip
            if self._create_package():
                return
            
            # Method 3: Show cloud build instructions
            self._show_cloud_instructions()
            
        except Exception as e:
            self._update_progress("❌ Build failed", str(e)[:100], 0)
            self._update_status(f"Error: {str(e)}")
        finally:
            def _enable_btn(dt):
                self.build_btn.disabled = False
            Clock.schedule_once(_enable_btn, 1)

    def _try_buildozer(self):
        """Try to build with buildozer."""
        try:
            self._update_progress("🔧 Using Buildozer...", "Setting up build environment", 20)
            
            # Check if buildozer is available
            result = subprocess.run(
                ["buildozer", "--version"], 
                capture_output=True, 
                text=True, 
                timeout=10
            )
            
            if result.returncode != 0:
                self._update_status("❌ Buildozer not available")
                return False
            
            self._update_progress("🏗️  Building APK...", "This may take several minutes", 30)
            
            # Run buildozer
            result = subprocess.run(
                ["buildozer", "android", "debug"],
                capture_output=True,
                text=True,
                timeout=1800,  # 30 minutes timeout
                cwd=os.getcwd()
            )
            
            if result.returncode == 0:
                self._update_progress("✅ Build successful!", "APK created successfully", 100)
                self._update_status("🎉 APK built successfully! Check the 'bin' folder.")
                
                # Check if APK exists
                apk_files = list(Path("bin").glob("*.apk"))
                if apk_files:
                    size_mb = apk_files[0].stat().st_size / (1024*1024)
                    self._update_status(f"📱 APK: {apk_files[0].name} ({size_mb:.1f} MB)")
                return True
            else:
                self._update_status(f"❌ Buildozer error: {result.stderr[:200]}")
                return False
                
        except subprocess.TimeoutExpired:
            self._update_status("⏰ Build timed out")
            return False
        except Exception as e:
            self._update_status(f"❌ Buildozer error: {str(e)}")
            return False

    def _create_package(self):
        """Create a distributable package."""
        try:
            self._update_progress("📦 Creating package...", "Zipping application files", 50)
            
            # Create package directory
            package_dir = Path("VideoDownloader_Package")
            package_dir.mkdir(exist_ok=True)
            
            # Copy essential files
            files_to_copy = [
                "app.py",
                "requirements.txt", 
                "buildozer.spec",
                "README.md",
                "setup.py"
            ]
            
            for file in files_to_copy:
                src = Path(file)
                if src.exists():
                    shutil.copy2(src, package_dir / file)
            
            # Create zip package
            zip_path = "VideoDownloader_Package.zip"
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file in package_dir.rglob('*'):
                    if file.is_file():
                        zipf.write(file, file.relative_to(package_dir))
            
            size_mb = os.path.getsize(zip_path) / (1024*1024)
            self._update_progress("✅ Package created!", f"Package ready for distribution", 100)
            self._update_status(f"📦 Package: {zip_path} ({size_mb:.1f} MB)\n"
                              f"📋 Contains all files needed for building")
            return True
            
        except Exception as e:
            self._update_status(f"❌ Package creation failed: {str(e)}")
            return False

    def _show_cloud_instructions(self):
        """Show cloud build instructions."""
        self._update_progress("☁️  Cloud Build", "Setup instructions ready", 80)
        
        instructions = (
            "🚀 CLOUD BUILD INSTRUCTIONS:\n\n"
            "1. Push code to GitHub\n"
            "2. GitHub Actions will build APK automatically\n"
            "3. Download APK from Actions artifacts\n\n"
            "📁 Files ready for cloud build:\n"
            "✅ app.py (main application)\n"
            "✅ buildozer.spec (build config)\n"
            "✅ .github/workflows/android.yml (CI/CD)\n\n"
            "🔗 GitHub Actions will handle everything!"
        )
        
        self._update_status(instructions)


# ─── HISTORY SCREEN ─────────────────────────────────────────────────────────────

class HistoryScreen(Screen):
    def __init__(self, **kw):
        super().__init__(**kw)
        with self.canvas.before:
            Color(*c(BG))
            self._bg = Rectangle()
        self.bind(pos=self._upd_bg, size=self._upd_bg)
        self._build_ui()

    def _upd_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size

    def _build_ui(self):
        scroll = ScrollView(do_scroll_x=False)
        root = BoxLayout(
            orientation="vertical",
            padding=dp(18),
            spacing=dp(14),
            size_hint_y=None,
        )
        root.bind(minimum_height=root.setter("height"))

        # Header
        root.add_widget(self._header())

        # History content
        self.history_content = BoxLayout(
            orientation="vertical",
            spacing=dp(10),
            size_hint_y=None,
        )
        self._load_history()
        root.add_widget(self.history_content)

        # Navigation
        nav = BoxLayout(
            orientation="horizontal",
            spacing=dp(10),
            size_hint_y=None,
            height=dp(50),
        )
        back_btn = SecondaryButton(text="🔙  Back")
        back_btn.bind(on_press=lambda *_: self._goto("home"))
        nav.add_widget(back_btn)
        root.add_widget(nav)

        root.add_widget(Widget(size_hint_y=None, height=dp(24)))

        scroll.add_widget(root)
        self.add_widget(scroll)

    def _header(self):
        box = BoxLayout(
            orientation="vertical",
            size_hint_y=None,
            height=dp(88),
            spacing=dp(4),
        )
        box.add_widget(
            Label(
                text="[b]DOWNLOAD[/b] [color=#FF4D6D]HISTORY[/color]",
                markup=True,
                font_size=sp(26),
                color=c(TEXT),
                size_hint_y=None,
                height=dp(48),
                halign="center",
            )
        )
        box.add_widget(
            MutedLabel(
                text="Previous downloads",
                font_size=sp(13),
                halign="center",
                size_hint_y=None,
                height=dp(26),
            )
        )
        return box

    def _goto(self, name):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = name

    def _load_history(self):
        """Load and display download history."""
        history = load_history()
        
        if not history:
            self.history_content.add_widget(
                MutedLabel(
                    text="No download history yet",
                    halign="center",
                    size_hint_y=None,
                    height=dp(40)
                )
            )
            return

        # Sort by date (newest first)
        sorted_history = sorted(
            history.items(), 
            key=lambda x: x[0], 
            reverse=True
        )

        for date_str, info in sorted_history[:20]:  # Show last 20 items
            try:
                date = datetime.fromisoformat(date_str)
                date_display = date.strftime("%Y-%m-%d %H:%M")
            except:
                date_display = date_str

            item_card = CardBox(
                orientation="vertical",
                padding=dp(12),
                spacing=dp(4),
                size_hint_y=None,
                height=dp(80),
            )
            
            item_card.add_widget(
                DarkLabel(
                    text=f"[b]{info.get('title', 'Unknown')[:40]}[/b]",
                    markup=True,
                    font_size=sp(14),
                    size_hint_y=None,
                    height=dp(22),
                )
            )
            
            details = (
                f"📅 {date_display}\n"
                f"🎯 {info.get('platform', 'Unknown')} • "
                f"📊 {info.get('quality', 'Unknown')}"
            )
            
            item_card.add_widget(
                MutedLabel(
                    text=details,
                    font_size=sp(11),
                    size_hint_y=None,
                    height=dp(40),
                )
            )
            
            self.history_content.add_widget(item_card)


# ─── MAIN APP ───────────────────────────────────────────────────────────────────

class VideoDownloaderApp(App):
    def build(self):
        # Create screen manager
        sm = ScreenManager()
        
        # Add screens
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(BuildScreen(name="build"))
        sm.add_widget(HistoryScreen(name="history"))
        
        return sm

    def on_start(self):
        """Called when app starts."""
        Window.clearcolor = c(BG)
        
        # Create download directory
        os.makedirs(DOWNLOADS_DIR, exist_ok=True)


if __name__ == "__main__":
    VideoDownloaderApp().run()