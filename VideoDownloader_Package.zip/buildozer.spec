[app]

# (str) Title of your application
title = Video Downloader By Khan XS

# (str) Package name
package.name = videodownloader

# (str) Package domain (needed for android/ios packaging)
package.domain = org.khanxs.videodownloader

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,json,txt

# (list) List of inclusions using pattern matching
#source.include_patterns = assets/*,images/*.png

# (list) Source files to exclude (let empty to not exclude anything)
#source.exclude_exts = spec

# (str) Application versioning (method 1)
version = 1.0

# (list) Application requirements
# comma separated e.g. requirements = sqlite3,kivy
requirements = python3,kivy==2.3.1,yt-dlp==2024.1.0,pillow==10.2.0,requests==2.31.0

# (str) Presplash of the application
#presplash.filename = %(source.dir)s/data/presplash.png

# (str) Icon of the application
#icon.filename = %(source.dir)s/data/icon.png

# (list) Supported orientations
# Valid options are: landscape, portrait, all
orientation = portrait

#
# Android specific
#

# (list) Permissions
android.permissions = WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,INTERNET

# (int) Target Android API, should be as high as possible.
android.api = 33

# (int) Minimum API your APK will support.
android.minapi = 21

# (str) Android NDK version to use
android.ndk = 25b

# (bool) If True, then skip trying to update the Android sdk
# This can be useful to avoid excess Internet downloads or save time
# when an update is due and you just want to test/build your package
# android.skip_update = False

# (str) Android entry point, default is ok for Kivy-based app
#android.entrypoint = org.renpy.android.PythonActivity

# (list) Pattern to whitelist for the whole project
#android.whitelist = *.so,*.py,*.png,*.jpg,*.jpeg,*.json,*.txt

# (str) Path to a custom whitelist file
#android.whitelist_src =

# (str) Path to a custom blacklist file
#android.blacklist_src =

# (list) List of Java .jar files to add to the libs so that pyjnius can access
# their classes. Like android.jar
#android.add_jars = jar1.jar,path/to/jar2.jar

# (list) List of Java .jar files to add to the libs so that pyjnius can access
# their classes. Like android.jar
#android.add_src_jars = jar1.jar,path/to/jar2.jar

# (list) Android AAR archives to add to the libs so that pyjnius can access
# their classes. Like android.jar
#android.add_aars = jar1.aar,path/to/jar2.aar

# (list) Gradle dependencies to add (using gav as org:name:ver)
#android.gradle_dependencies =

# (list) add java compile options
# this can help to solve issues when building with python 3.7/3.8
#android.java_compile_options = -source 1.8 -target 1.8

# (list) Gradle repositories
#android.gradle_repositories =

# (list) Android additional libraries to copy into libs/armeabi
#android.add_libs_armeabi = libs/android/*.so
#android.add_libs_armeabi_v7a = libs/android-v7/*.so
#android.add_libs_arm64_v8a = libs/android-v8/*.so
#android.add_libs_x86 = libs/android-x86/*.so
#android.add_libs_mips = libs/android-mips/*.so

# (bool) Indicate whether the screen should stay on
# Don't set to True by default. It's a developer option.
android.wakelock = False

# (list) Android application meta-data to set (key=value format)
#android.meta_data =

# (list) Android library project to add (will be added in the
# project.properties automatically.)
#android.library_references =

# (list) Android shared libraries which will be added to AndroidManifest.xml
#android.shared_libs =

# (str) Android logcat filters to use
android.logcat_filters = *:S python:D

# (bool) Copy library instead of making a libpymodules.so
#android.copy_libs = 1

# (str) The Android arch to build for, choices: armeabi-v7a, arm64-v8a, x86, x86_64
# In past, was `android.arch` as we weren't supporting builds for multiple archs at the same time.
android.archs = arm64-v8a, armeabi-v7a

#
# Python for android (p4a) specific
#

# (str) python-for-android branch to use, defaults to master
#p4a.branch = master

# (str) python-for-android specific commit to use, defaults to HEAD, must be in p4a.branch
#p4a.commit = HEAD

# (str) python-for-android git tree directory
#p4a.source_dir =

# (str) python-for-android build directory
#p4a.build_dir =

# (int) python-for-android bootstrap to use, options: sdl2, pygame, service_only
#p4a.bootstrap = sdl2

# (int) python-for-android bootstrap to use, options: sdl2, pygame, service_only
# (str) python-for-android DRC recipes to build
#p4a.drc_recipes =

# (str) python-for-android DRC additional arguments
#p4a.drc_args =

# (str) python-for-android Android NDK directory
#p4a.ndk_dir =

# (str) python-for-android Android SDK directory
#p4a.sdk_dir =

# (str) python-for-android ANT directory (deprecated)
#p4a.ant_dir =

# (bool) python-for-android use git to clone p4a recipes
#p4a.use_git = 1

# (int) python-for-android DRC recipe build timeout
#p4a.drc_timeout = 60

#
# Kivy specific
#

# (list) Patterns to exclude from finding the Kivy installation
#kivy.exclude_patterns =

# (str) Python command to use for building the Kivy APK
# (default is python3)
#kivy.python = python3

#
# iOS specific
#

# (str) Path to a custom kivy-ios directory
#ios.kivy_ios_dir =

# (str) Name of the certificate to use for signing the debug version
#ios.debug_certificate =

# (str) The name of the certificate
#ios.release_certificate =

# (str) The provisioning profile to use
#ios.provisioning_profile =

#
# Packaging specific
#

# (bool) Specify if a debug APK should be built
# (default is False)
#android.debug = False

# (bool) Specify if a release APK should be built
# (default is False)
#android.release = False

# (bool) Copy private libraries into APK
# (list) Whitelist of private libraries to copy into APK
#android.private_libs =

# (str) The key alias to use for signing the release APK
#android.release_key_alias =

# (str) The key password to use for signing the release APK
#android.release_key_password =

# (str) The key store to use for signing the release APK
#android.release_keystore =

# (str) The key store password to use for signing the release APK
#android.release_keystore_password =

#
# URLs
#

# (str) URL to download the latest buildozer release
#buildozer.version_url = https://github.com/kivy/buildozer/releases/download

# (str) URL to download the latest p4a release
#p4a.version_url = https://github.com/kivy/python-for-android/releases/download

#
# Misc
#

# (bool) Indicate if buildozer should delete the output folder (bin) before building
# (default is False)
#buildozer.clean = False

# (bool) Indicate if buildozer should delete the .buildozer folder before building
# (default is False)
#buildozer.clean_build = False

# (bool) Indicate if buildozer should log to stdout
# (default is True)
#buildozer.log_stdout = True

# (bool) Increase the build timeout
#buildozer.build_timeout = 1200

# (bool) Raise an exception if build fails
#buildozer.raise_on_build_timeout = True

# (str) Path to build artifact storage, absolute or relative to spec file
#buildozer.bin_dir = ./bin

# (str) Path to build output (i.e. .apk, .aab, .ipa) storage
#buildozer.output_dir = ./bin
