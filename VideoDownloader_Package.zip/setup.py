#!/usr/bin/env python3
"""
Setup script for Video Downloader Android App
"""

import os
import sys
import subprocess
from pathlib import Path

def run_command(cmd, description):
    """Run a command and handle errors"""
    print(f"\n🔄 {description}")
    print(f"Running: {cmd}")
    
    try:
        result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
        print("✅ Success!")
        if result.stdout:
            print(f"Output: {result.stdout}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: {e}")
        if e.stderr:
            print(f"Error details: {e.stderr}")
        return False

def check_dependencies():
    """Check if required tools are installed"""
    print("🔍 Checking dependencies...")
    
    dependencies = [
        ("python3", "Python 3"),
        ("pip", "Pip package manager"),
        ("git", "Git"),
    ]
    
    missing = []
    for cmd, name in dependencies:
        try:
            subprocess.run([cmd, "--version"], check=True, capture_output=True)
            print(f"✅ {name} found")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"❌ {name} not found")
            missing.append(name)
    
    if missing:
        print(f"\n⚠️  Missing dependencies: {', '.join(missing)}")
        print("Please install them before continuing.")
        return False
    
    return True

def install_python_deps():
    """Install Python dependencies"""
    print("\n📦 Installing Python dependencies...")
    
    if not run_command("pip install -r requirements.txt", "Installing Python packages"):
        return False
    
    if not run_command("pip install buildozer", "Installing Buildozer"):
        return False
    
    return True

def setup_android_env():
    """Setup Android environment (Ubuntu/Debian)"""
    print("\n🤖 Setting up Android environment...")
    
    commands = [
        ("sudo apt update", "Updating package lists"),
        ("sudo apt install -y python3-pip build-essential git python3 python3-dev", "Installing build essentials"),
        ("sudo apt install -y libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev", "Installing SDL2 libraries"),
        ("sudo apt install -y libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev", "Installing media libraries"),
        ("sudo apt install -y default-jdk autoconf libtool pkg-config", "Installing Java and build tools"),
        ("sudo apt install -y libssl-dev", "Installing SSL library"),
    ]
    
    for cmd, desc in commands:
        if not run_command(cmd, desc):
            print(f"⚠️  Failed to: {desc}")
            print("You may need to install this manually")
    
    return True

def build_apk():
    """Build the APK"""
    print("\n🔨 Building APK...")
    
    # Clean previous builds
    if os.path.exists("bin"):
        run_command("rm -rf bin", "Cleaning previous builds")
    
    # Build debug APK
    if not run_command("buildozer android debug", "Building debug APK"):
        return False
    
    # Check if APK was created
    apk_files = list(Path("bin").glob("*.apk"))
    if apk_files:
        print(f"\n🎉 APK built successfully!")
        print(f"📱 APK location: {apk_files[0]}")
        return True
    else:
        print("❌ APK not found after build")
        return False

def main():
    """Main setup process"""
    print("🚀 Video Downloader - Android Setup")
    print("=" * 50)
    
    # Check current directory
    if not os.path.exists("app.py"):
        print("❌ app.py not found in current directory!")
        print("Please run this script from the project root.")
        sys.exit(1)
    
    # Menu
    print("\n📋 Setup Options:")
    print("1. Install Python dependencies only")
    print("2. Setup Android environment (Ubuntu/Debian)")
    print("3. Build APK")
    print("4. Full setup (1 + 2 + 3)")
    print("5. Exit")
    
    choice = input("\nEnter your choice (1-5): ").strip()
    
    if choice == "1":
        if not check_dependencies():
            sys.exit(1)
        install_python_deps()
        
    elif choice == "2":
        setup_android_env()
        
    elif choice == "3":
        if not build_apk():
            sys.exit(1)
            
    elif choice == "4":
        print("\n🔄 Starting full setup...")
        
        if not check_dependencies():
            sys.exit(1)
            
        if not install_python_deps():
            sys.exit(1)
            
        setup_android_env()
        
        if not build_apk():
            sys.exit(1)
            
        print("\n🎉 Setup completed successfully!")
        print("📱 You can now install the APK on your Android device.")
        
    elif choice == "5":
        print("👋 Goodbye!")
        sys.exit(0)
        
    else:
        print("❌ Invalid choice!")
        sys.exit(1)

if __name__ == "__main__":
    main()
